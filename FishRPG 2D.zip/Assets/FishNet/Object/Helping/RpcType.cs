﻿namespace FishNet.Object.Helping
{
    public enum RpcType
    {
        None,
        Server,
        Observers,
        Target
    }

}