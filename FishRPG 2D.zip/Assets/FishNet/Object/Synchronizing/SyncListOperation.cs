﻿
namespace FishNet.Object.Synchronizing
{

    public enum SyncListOperation : byte
    {
        Add,
        Insert,
        Set,
        RemoveAt,
        Clear,
        Complete
    }

}
