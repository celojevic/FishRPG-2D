namespace FishNet.Object.Synchronizing
{
    /// <summary>
    /// Permission type.
    /// </summary>
    public enum ReadPermission
    {
        Observers,
        OwnerOnly
    }
}