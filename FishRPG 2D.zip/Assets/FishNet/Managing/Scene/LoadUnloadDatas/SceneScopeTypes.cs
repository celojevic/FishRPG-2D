﻿namespace FishNet.Managing.Scened.Data
{

    public enum SceneScopeTypes : byte
    {
        Networked = 0,
        Connections = 1
    }

}   