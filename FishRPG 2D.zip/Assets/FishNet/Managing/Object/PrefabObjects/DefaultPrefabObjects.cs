using FishNet.Object;
using System.Collections.Generic;
using UnityEngine;

namespace FishNet.Managing.Object
{

    //[CreateAssetMenu(fileName = "New DefaultPrefabObjects", menuName = "FishNet/Spawnable Prefabs/Default Prefab Objects")]
    public class DefaultPrefabObjects : SinglePrefabObjects { }

}