﻿#if UNITY_EDITOR
using UnityEditor;
#endif
using FishNet.Connection;
using FishNet.Managing.Client;
using FishNet.Managing.Server;
using FishNet.Managing.Timing;
using FishNet.Managing.Transporting;
using FishNet.Managing.Object;
//using FishNet.Managing.Scened;
using UnityEngine;
using FishNet.Managing.Scened;

namespace FishNet.Managing
{
    //Set execution order to make sure this fires Awake first.
    [DefaultExecutionOrder(short.MinValue)]
    public class NetworkManager : MonoBehaviour
    {

        #region Public.
        /// <summary>
        /// True if server is active.
        /// </summary>
        public bool IsServer => ServerManager.Active;
        /// <summary>
        /// True if the client is running and authenticated.
        /// </summary>
        public bool IsClient => ClientManager.Active;
        /// <summary>
        /// True if client and server are active.
        /// </summary>
        public bool IsHost => (ServerManager.Active && ClientManager.Active);
        /// <summary>
        /// NetworkServer for this NetworkManager.
        /// </summary>
        public ServerManager ServerManager { get; private set; } = null;
        /// <summary>
        /// NetworkClient for this NetworkManager.
        /// </summary>
        public ClientManager ClientManager { get; private set; } = null;
        /// <summary>
        /// TransportManager for this NetworkManager.
        /// </summary>
        public TransportManager TransportManager { get; private set; } = null;
        /// <summary>
        /// TimeManager for this NetworkManager.
        /// </summary>
        public TimeManager TimeManager { get; private set; } = null;
        /// <summary>
        /// SceneManager for this NetworkManager.
        /// </summary>
        public SceneManager SceneManager { get; private set; } = null;
        /// <summary>
        /// An empty connection. Passed around when a connection cannot be found to prevent object creation per not found case.
        /// </summary>
        public NetworkConnection EmptyConnection { get; private set; } = new NetworkConnection();
        #endregion

        #region Serialized.
        /// <summary>
        /// True to have your application run while in the background.
        /// </summary>
        [Tooltip("True to have your application run while in the background.")]
        [SerializeField]
        private bool _runInBackground = true;
        /// <summary>
        /// True to make this instance DontDestroyOnLoad. This is typical if you only want one NetworkManager.
        /// </summary>
        [Tooltip("True to make this instance DontDestroyOnLoad. This is typical if you only want one NetworkManager.")]
        [SerializeField]
        private bool _dontDestroyOnLoad = true;
        /// <summary>
        /// True to allow multiple NetworkManagers. When false any copies will be destroyed.
        /// </summary>
        [Tooltip("True to allow multiple NetworkManagers. When false any copies will be destroyed.")]
        [SerializeField]
        private bool _allowMultiple = false;
        /// <summary>
        /// 
        /// </summary>
        [Tooltip("Collection to use for spawnable objects.")]
        [SerializeField]
        private PrefabObjects _spawnablePrefabs = null;
        /// <summary>
        /// Collection to use for spawnable objects.
        /// </summary>
        public PrefabObjects SpawnablePrefabs => _spawnablePrefabs;
        #endregion

        protected virtual void Awake()
        {
            if (WillBeDestroyed())
                return;

            _spawnablePrefabs.InitializePrefabRange(0);
            SetDontDestroyOnLoad();
            SetRunInBackground();
            EmptyConnection = new NetworkConnection();
            FindTransportManager();
            AddTimeManager();
            AddNetworkServerAndClient();
            AddSceneManager();
            ServerManager.Initialize(this);
            ClientManager.Initialize(this);
        }

        protected virtual void LateUpdate()
        {
            /* Some reason runinbackground becomes unset
             * or the setting goes ignored some times when it's set
             * in awake. Rather than try to fix or care why Unity
             * does this just set it in LateUpdate(or Update). */
            SetRunInBackground();
            ServerManager.Objects.CheckDirtySyncTypes();
        }

        /// <summary>
        /// Returns if this NetworkManager can exist.
        /// </summary>
        /// <returns></returns>
        private bool WillBeDestroyed()
        {
            if (_allowMultiple)
                return true;

            //If here multiple are not allowed.
            NetworkManager nm = InstanceFinder.NetworkManager;
            //If found NetworkManager isn't this copy then return false.
            bool destroyThis = (nm != this);

            if (destroyThis)
            {
                Debug.Log($"NetworkManager on object {gameObject.name} is a duplicate and will be destroyed. If you wish to have multiple NetworkManagers enable 'Allow Multiple'.");
                Destroy(gameObject);
            }

            return destroyThis;
        }

        /// <summary>
        /// Sets DontDestroyOnLoad if configured to.
        /// </summary>
        private void SetDontDestroyOnLoad()
        {
            if (_dontDestroyOnLoad)
                DontDestroyOnLoad(this);
        }

        /// <summary>
        /// Sets Application.runInBackground to runInBackground.
        /// </summary>
        private void SetRunInBackground()
        {
            Application.runInBackground = _runInBackground;
        }

        /// <summary>
        /// Finds TransportManager on this object.
        /// </summary>
        private void FindTransportManager()
        {
            if (TransportManager == null)
                TransportManager = GetComponent<TransportManager>();
        }

        /// <summary>
        /// Adds TimeManager.
        /// </summary>
        private void AddTimeManager()
        {
            if (gameObject.TryGetComponent<TimeManager>(out TimeManager result))
                TimeManager = result;
            else
                TimeManager = gameObject.AddComponent<TimeManager>();

            TimeManager.FirstInitialize(this);
        }


        /// <summary>
        /// Adds SceneManager.
        /// </summary>
        private void AddSceneManager()
        {
            if (gameObject.TryGetComponent<SceneManager>(out SceneManager result))
                SceneManager = result;
            else
                SceneManager = gameObject.AddComponent<SceneManager>();

            SceneManager.FirstInitialize(this);
        }

        /// <summary>
        /// Adds and assigns NetworkServer and NetworkClient if they are not already setup.
        /// </summary>
        private void AddNetworkServerAndClient()
        {
            //Add ServerManager if missing.
            if (gameObject.TryGetComponent<ServerManager>(out ServerManager sm))
                ServerManager = sm;
            else
                ServerManager = gameObject.AddComponent<ServerManager>();

            ClientManager = new ClientManager();
        }


        #region Editor.
#if UNITY_EDITOR
        private void OnValidate()
        { 
            FindTransportManager();
        }
        protected virtual void Reset()
        {
            if (_spawnablePrefabs == null)
            {
                _spawnablePrefabs = DefaultPrefabsFinder.GetDefaultPrefabsFile(out _);
                //If found.
                if (_spawnablePrefabs != null)
                    Debug.Log($"NetworkManager on {gameObject.name} is using the default prefabs collection.");
            }
        }
#endif
        #endregion

    }


}