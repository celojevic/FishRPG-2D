﻿namespace FishNet.Transporting
{

    public enum Channel : byte
    {
        Reliable = 0,
        Unreliable = 1
    }


}