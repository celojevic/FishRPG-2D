﻿using FishNet.Connection;
using UnityEngine.Events;

namespace FishNet.Transporting
{

    public class NetworkConnectionEvent : UnityEvent<NetworkConnection> { }

}