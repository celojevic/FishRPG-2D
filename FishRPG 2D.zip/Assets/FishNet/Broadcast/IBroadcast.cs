﻿
namespace FishNet.Broadcast
{
    public interface IBroadcast { }
}