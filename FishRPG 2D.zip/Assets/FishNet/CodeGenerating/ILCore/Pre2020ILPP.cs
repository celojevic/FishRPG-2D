#if !UNITY_2020_2_OR_NEWER
using Mono.Cecil;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Unity.CompilationPipeline.Common.Diagnostics;
using Unity.CompilationPipeline.Common.ILPostProcessing;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;
using Assembly = System.Reflection.Assembly;


namespace FishNet.CodeGenerating.ILCore.Pre2020
{

    public class ILPostProcessProgram
    {
        private static FishNetILPP _fishNetILPP = new FishNetILPP();

        [InitializeOnLoadMethod]
        private static void OnInitializeOnLoad()
        {
            CompilationPipeline.assemblyCompilationFinished += OnCompilationFinished;

            string firstInitialized = "FirstInitialized";
            if (!SessionState.GetBool(firstInitialized, false))
            {
                SessionState.SetBool(firstInitialized, true);
                CodegenExistingAssemblies();
            }
        }


        private static bool GetDependencyPaths(string targetAssembly, out List<string> dependencyPaths)
        {
            dependencyPaths = new List<string>();

            string unityEngineAssemblyPath = string.Empty;
            string fishNetAssemblyPath = string.Empty;
            bool foundTargetAssembly = false;
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();

            foreach (Assembly assembly in assemblies)
            {
                // Find the assembly currently being compiled from domain assembly list and check if it's using FishNet.
                if (assembly.GetName().Name == Path.GetFileNameWithoutExtension(targetAssembly))
                {
                    foundTargetAssembly = true;
                    foreach (System.Reflection.AssemblyName dependency in assembly.GetReferencedAssemblies())
                    {
                        // Since this assembly is already loaded in the domain this is a no-op and returns the
                        // already loaded assembly
                        dependencyPaths.Add(Assembly.Load(dependency).Location);
                    }
                }

                try
                {
                    //Set assembly paths.
                    if (assembly.Location.Contains("UnityEngine.CoreModule"))
                        unityEngineAssemblyPath = assembly.Location;
                    if (assembly.Location.Contains(FishNetILPP.RUNTIME_ASSEMBLY_NAME))
                        fishNetAssemblyPath = assembly.Location;
                }
                catch (NotSupportedException)
                {
                    // in memory assembly, can't get location
                }
            }

            if (!foundTargetAssembly)
            {
                // Target assembly not found in current domain, trying to load it to check references 
                // will lead to trouble in the build pipeline, so lets assume it should go to weaver.
                // Add all assemblies in current domain to dependency list since there could be a 
                // dependency lurking there (there might be generated assemblies so ignore file not found exceptions).
                // (can happen in runtime test framework on editor platform and when doing full library reimport)
                foreach (Assembly assembly in assemblies)
                {
                    try
                    {
                        if (!(assembly.ManifestModule is System.Reflection.Emit.ModuleBuilder))
                            dependencyPaths.Add(Assembly.Load(assembly.GetName().Name).Location);
                    }
                    catch (FileNotFoundException)
                    {
                    }
                }
            }

            //If either paths are missing return false.
            if (string.IsNullOrEmpty(unityEngineAssemblyPath))
            {
                Debug.LogError("Failed to find UnityEngine assembly");
                return false;
            }
            else if (string.IsNullOrEmpty(fishNetAssemblyPath))
            {
                Debug.LogError("Failed to find FishNet runtime assembly");
                return false;
            }
            else
            {
                return true;
            }
        }

        public static void CodegenExistingAssemblies()
        {
            foreach (UnityEditor.Compilation.Assembly assembly in CompilationPipeline.GetAssemblies())
            {
                if (File.Exists(assembly.outputPath))
                    TryCompileAssembly(assembly.outputPath, new CompilerMessage[0], false);
            }

#if UNITY_2019_3_OR_NEWER
            EditorUtility.RequestScriptReload();
#else
            UnityEditorInternal.InternalEditorUtility.RequestScriptReload();
#endif
        }

        private static void TryCompileAssembly(string targetAssembly, CompilerMessage[] messages, bool reloadFishNet = true)
        {
            //If any of the compile messages are errors.
            if (messages.Length > 0)
            {
                if (messages.Any(msg => msg.type == CompilerMessageType.Error))
                    return;
            }

            //Where assembles are built.
            string outputDirectory = $"{Application.dataPath}/../{Path.GetDirectoryName(targetAssembly)}";

            List<string> dependencyPaths;
            bool dependenciesFound = GetDependencyPaths(targetAssembly, out dependencyPaths);
            if (!dependenciesFound)
                return;

            string assemblyPathName = Path.GetFileName(targetAssembly);
            ILPostProcessCompiledAssembly compiledAssembly = new ILPostProcessCompiledAssembly(assemblyPathName, dependencyPaths.ToArray(), null, outputDirectory);

            //Get assembly definition to read.
            AssemblyDefinition assemblyDef = ILCoreHelper.GetAssemblyDefinition(compiledAssembly);
            if (assemblyDef == null)
            {
                Debug.LogError($"Cannot read assembly definition: {compiledAssembly.Name}");
                return;
            }
            ModuleDefinition moduleDef = assemblyDef.MainModule;
            if (moduleDef == null)
            {
                Debug.LogError($"Cannot get the main module for {assemblyDef.Name}.");
                return;
            }

            List<DiagnosticMessage> diagnostics = new List<DiagnosticMessage>();

            string ppName = "FishNet";
            diagnostics.Clear();

            //Result of il post process.
            ILPostProcessResult result = null;

            Debug.Log("Checking to process " + compiledAssembly.Name + ",  " + targetAssembly);
            if (_fishNetILPP.WillProcess(compiledAssembly, moduleDef, diagnostics))
            {
                Debug.Log("Processing " + compiledAssembly.Name);
                result = _fishNetILPP.Process(assemblyDef, moduleDef, diagnostics);
                //Print out any diagnostics.
                if (diagnostics.Count > 0)
                {
                    ILCoreHelper.PrintDiagnostics(diagnostics, compiledAssembly, ppName);
                }
                else
                {
                    //Write any assembly changes.
                    if (result == null)
                        Debug.LogWarning($"Codegen result is unexpectedly null on {compiledAssembly.Name}.");
                    else
                        WriteAssembly(result.InMemoryAssembly, outputDirectory, assemblyPathName);
                }
            }

        }
        private static void OnCompilationFinished(string targetAssembly, CompilerMessage[] messages)
        {
            TryCompileAssembly(targetAssembly, messages);
        }

        /// <summary>
        /// Writes any changes to an assembly.
        /// </summary>
        /// <param name="inMemoryAssembly"></param>
        /// <param name="outputPath"></param>
        /// <param name="asmName"></param>
        private static void WriteAssembly(InMemoryAssembly inMemoryAssembly, string outputPath, string asmName)
        {
            if (inMemoryAssembly == null)
            {
                Debug.LogError($"InMemoryAssembly has never been accessed or modified.");
                return;
            }

            var asmPath = Path.Combine(outputPath, asmName);
            var pdbFileName = $"{Path.GetFileNameWithoutExtension(asmName)}.pdb";
            var pdbPath = Path.Combine(outputPath, pdbFileName);
            File.WriteAllBytes(asmPath, inMemoryAssembly.PeData);
            File.WriteAllBytes(pdbPath, inMemoryAssembly.PdbData);
        }
    }
}

#endif