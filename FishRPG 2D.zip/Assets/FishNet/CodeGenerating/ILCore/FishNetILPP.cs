﻿using System.IO;
using System.Linq;
using System.Collections.Generic;
using Mono.Cecil;
using Mono.Cecil.Cil;
using Unity.CompilationPipeline.Common.Diagnostics;
using Unity.CompilationPipeline.Common.ILPostProcessing;
using UnityEngine;
using FishNet.CodeGenerating.Helping;
using FishNet.CodeGenerating.Processing;
using FishNet.CodeGenerating.Helping.Extension;
using FishNet.Broadcast;

#if !UNITY_2020_2_OR_NEWER
using FishNet.CodeGenerating.ILCore.Pre2020;
#endif

namespace FishNet.CodeGenerating.ILCore
{
#if !UNITY_2020_2_OR_NEWER
    public class FishNetILPP
#else
    public class FishNetILPP : ILPostProcessor
#endif
    {
        #region Const.
        internal const string RUNTIME_ASSEMBLY_NAME = "FishNet";
        #endregion
#if !UNITY_2020_2_OR_NEWER
        internal bool WillProcess(ILPostProcessCompiledAssembly compiledAssembly, ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics) => WillProcessCommon(compiledAssembly, moduleDef, diagnostics);
        internal ILPostProcessResult Process(AssemblyDefinition assemblyDef, ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics) => ProcessCommon(assemblyDef, moduleDef, diagnostics);
#else
        public override bool WillProcess(ICompiledAssembly compiledAssembly) => WillProcessCommon(compiledAssembly);
        public override ILPostProcessor GetInstance() => this;
        public override ILPostProcessResult Process(ICompiledAssembly compiledAssembly)
        {
            AssemblyDefinition assemblyDef = ILCoreHelper.GetAssemblyDefinition(compiledAssembly);
            if (assemblyDef == null)
                return null;

            List<DiagnosticMessage> diagnostics = new List<DiagnosticMessage>();
            ILPostProcessResult result = ProcessCommon(assemblyDef, assemblyDef.MainModule, diagnostics);


            if (diagnostics.Count > 0)
            {
                ILCoreHelper.PrintDiagnostics(diagnostics, compiledAssembly, "FishNetILPP");
                result = null;
            }

            return result;
        }
#endif

        /// <summary>
        /// Returns if assembly can be processed.
        /// </summary>
        /// <param name="compiledAssembly"></param>
        /// <returns></returns>
#if !UNITY_2020_2_OR_NEWER
        private bool WillProcessCommon(ILPostProcessCompiledAssembly compiledAssembly, ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics)
#else
        private bool WillProcessCommon(ICompiledAssembly compiledAssembly)
#endif
        {
            if (compiledAssembly.Name.StartsWith("Unity."))
                return false;
            if (compiledAssembly.Name.StartsWith("UnityEngine."))
                return false;
            if (compiledAssembly.Name.StartsWith("UnityEditor."))
                return false;
            if (compiledAssembly.Name.Contains("Editor"))
                return false;

#if !UNITY_2020_2_OR_NEWER
            bool referencesFishNet = FishNetILPP.IsFishNetAssembly(moduleDef) || compiledAssembly.References.Any(filePath => Path.GetFileNameWithoutExtension(filePath) == RUNTIME_ASSEMBLY_NAME);
#else
            bool referencesFishNet = FishNetILPP.IsFishNetAssembly(compiledAssembly) || compiledAssembly.References.Any(filePath => Path.GetFileNameWithoutExtension(filePath) == RUNTIME_ASSEMBLY_NAME);
#endif
            return referencesFishNet;
        }


        private ILPostProcessResult ProcessCommon(AssemblyDefinition assemblyDef, ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics)
        {
            if (!ImportReferences(moduleDef, diagnostics))
                Debug.LogError($"Could not import references for {moduleDef.Name}.");

            CreateDeclaredDelegates(moduleDef, diagnostics);
            CreateDeclaredSerializers(moduleDef, diagnostics);
            CreateIBroadcast(moduleDef, diagnostics);
            CreateNetworkBehaviours(moduleDef, diagnostics);
            CreateGenericReadWriteDelegates(moduleDef, diagnostics);

            return GetPostProcessResult(assemblyDef, diagnostics);
        }

        /// <summary>
        /// Creates delegates for user declared serializers.
        /// </summary>
        /// <param name="moduleDef"></param>
        /// <param name="diagnostics"></param>
        private void CreateDeclaredDelegates(ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics)
        {
            TypeAttributes readWriteExtensionTypeAttr = (TypeAttributes.Public | TypeAttributes.Sealed | TypeAttributes.Abstract);
            List<TypeDefinition> allTypeDefs = moduleDef.Types.ToList();
            foreach (TypeDefinition td in allTypeDefs)
            {
                if (GeneralHelper.IgnoreTypeDefinition(td))
                    continue;

                if (td.Attributes.HasFlag(readWriteExtensionTypeAttr))
                    CustomSerializerProcessor.CreateDelegates(td, moduleDef, diagnostics);
            }
        }

        /// <summary>
        /// Creates serializers for custom types within user declared serializers.
        /// </summary>
        /// <param name="moduleDef"></param>
        /// <param name="diagnostics"></param>
        private void CreateDeclaredSerializers(ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics)
        {
            TypeAttributes readWriteExtensionTypeAttr = (TypeAttributes.Public | TypeAttributes.Sealed | TypeAttributes.Abstract);
            List<TypeDefinition> allTypeDefs = moduleDef.Types.ToList();
            foreach (TypeDefinition td in allTypeDefs)
            {
                if (GeneralHelper.IgnoreTypeDefinition(td))
                    continue;

                if (td.Attributes.HasFlag(readWriteExtensionTypeAttr))
                    CustomSerializerProcessor.CreateSerializers(td, moduleDef, diagnostics);
            }
        }

        /// <summary>
        /// Creaters serializers and calls for IBroadcast.
        /// </summary>
        /// <param name="moduleDef"></param>
        /// <param name="diagnostics"></param>
        private void CreateIBroadcast(ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics)
        {
            HashSet<TypeDefinition> typeDefs = new HashSet<TypeDefinition>();
            foreach (TypeDefinition td in moduleDef.Types)
            {
                TypeDefinition climbTypeDef = td;
                while (climbTypeDef != null)
                {
                    /* Check initial class as well all types within
                     * the class. Then check all of it's base classes. */
                    if (climbTypeDef.ImplementsInterface<IBroadcast>())
                        typeDefs.Add(climbTypeDef);

                    //Add nested. Only going to go a single layer deep.
                    foreach (TypeDefinition nestedTypeDef in td.NestedTypes)
                    {
                        if (nestedTypeDef.ImplementsInterface<IBroadcast>())
                            typeDefs.Add(nestedTypeDef);
                    }

                    //Climb up base classes.
                    if (climbTypeDef.BaseType != null)
                        climbTypeDef = climbTypeDef.BaseType.Resolve();
                    else
                        climbTypeDef = null;
                }
            }

            //Create reader/writers for found typeDefs.
            foreach (TypeDefinition td in typeDefs)
            {
                TypeReference typeRef = moduleDef.ImportReference(td);

                bool canSerialize = GeneralHelper.HasSerializerAndDeserializer(typeRef, true, diagnostics);
                if (!canSerialize)
                    diagnostics.AddError($"Broadcast {td.Name} does not support serialization. Use a supported type or create a custom serializer.");
            }
        }

        /// <summary>
        /// Creates NetworkBehaviour changes.
        /// </summary>
        /// <param name="moduleDef"></param>
        /// <param name="diagnostics"></param>
        private void CreateNetworkBehaviours(ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics)
        {
            //Get all network behaviours to process.
            List<TypeDefinition> networkBehaviourTypeDefs = moduleDef.Types
                .Where(td => td.IsSubclassOf(ObjectHelper.NetworkBehaviour_FullName))
                .ToList();

            /* Remove any networkbehaviour typedefs which are inherited by
             * another networkbehaviour typedef. When a networkbehaviour typedef
             * is processed so are all of the inherited types. */
            for (int i = 0; i < networkBehaviourTypeDefs.Count; i++)
            {
                int entriesRemoved = 0;

                List<TypeDefinition> tdSubClasses = new List<TypeDefinition>();
                TypeDefinition tdClimb = networkBehaviourTypeDefs[i].BaseType.Resolve();
                while (tdClimb != null)
                {
                    tdSubClasses.Add(tdClimb);
                    if (tdClimb.NonNetworkBehaviourBaseType())
                        tdClimb = tdClimb.BaseType.Resolve();
                    else
                        tdClimb = null;
                }
                //No base types to compare.
                if (tdSubClasses.Count == 0)
                    continue;
                //Try to remove every subclass.
                foreach (TypeDefinition tdSub in tdSubClasses)
                {
                    if (networkBehaviourTypeDefs.Remove(tdSub))
                        entriesRemoved++;
                }
                //Subtract entries removed from i since theyre now gone.
                i -= entriesRemoved;
            }

            /* This needs to persist because it holds SyncHandler
             * references for each SyncType. Those
             * SyncHandlers are re-used if there are multiple SyncTypes
             * using the same Type. */
            List<(SyncType, ProcessedSync)> allProcessedSyncs = new List<(SyncType, ProcessedSync)>();

            HashSet<string> allProcessedCallbacks = new HashSet<string>();

            foreach (TypeDefinition typeDef in networkBehaviourTypeDefs)
            {
                moduleDef.ImportReference(typeDef);
                //RPCs are per networkbehaviour + hierarchy and need to be reset.
                int allRpcCount = 0;
                //Callbacks are per networkbehaviour + hierarchy as well.
                allProcessedCallbacks.Clear();
                NetworkBehaviourProcessor.Process(moduleDef, null, typeDef, ref allRpcCount, allProcessedSyncs, allProcessedCallbacks, diagnostics);

                //Register rpc count on each script that inherits from network behaviour.
                TypeDefinition climbTypeDef = typeDef;
                while (climbTypeDef != null)
                {
                    NetworkBehaviourProcessor.CreateRegisterRpcCount(climbTypeDef, allRpcCount, diagnostics);
                    if (climbTypeDef.BaseType != null && climbTypeDef.BaseType.FullName != ObjectHelper.NetworkBehaviour_FullName)
                        climbTypeDef = climbTypeDef.BaseType.Resolve();
                    else
                        climbTypeDef = null;
                }
            }
        }


        /// <summary>
        /// Creates generic delegates for all read and write methods.
        /// </summary>
        /// <param name="moduleDef"></param>
        /// <param name="diagnostics"></param>
        private void CreateGenericReadWriteDelegates(ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics)
        {
            //Don't make generic delegates for internals.
            //if (moduleDef.Assembly.Name.Name == FishNetILPP.RUNTIME_ASSEMBLY_NAME)
            //return;

            WriterHelper.CreateGenericDelegates(moduleDef, diagnostics);
            ReaderHelper.CreateGenericDelegates(moduleDef, diagnostics);

            /* This is breaking on imported references. Would like to get this working eventually
             * so I don't have to manually make static writers for included types. */
            //foreach (var item in WriterHelper._instancedWriterMethods.Values)
            //    GenericWriterHelper.CreateInstancedStaticWrite(item, diagnostics);
        }

        /// <summary>
        /// Returns results. To be called after all creates.
        /// </summary>
        /// <param name="diagnostics"></param>
        /// <returns></returns>
        private ILPostProcessResult GetPostProcessResult(AssemblyDefinition assemblyDef, List<DiagnosticMessage> diagnostics)
        {
            MemoryStream pe = new MemoryStream();
            MemoryStream pdb = new MemoryStream();
            WriterParameters writerParameters = new WriterParameters
            {
                SymbolWriterProvider = new PortablePdbWriterProvider(),
                SymbolStream = pdb,
                WriteSymbols = true
            };

            assemblyDef.Write(pe, writerParameters);
            return new ILPostProcessResult(new InMemoryAssembly(pe.ToArray(), pdb.ToArray()), diagnostics);
        }

        /// <summary>
        /// Imports references into all helpers.
        /// </summary>
        /// <param name="moduleDef"></param>
        private bool ImportReferences(ModuleDefinition moduleDef, List<DiagnosticMessage> diagnostics)
        {
            if (!ReaderHelper.ImportReferences(moduleDef, diagnostics))
                return false;
            if (!GeneralHelper.ImportReferences(moduleDef))
                return false;
            if (!WriterHelper.ImportReferences(moduleDef, diagnostics))
                return false;
            if (!TransportHelper.ImportReferences(moduleDef))
                return false;
            if (!ObjectHelper.ImportReferences(moduleDef))
                return false;
            if (!WriterGenerator.ImportReferences(moduleDef))
                return false;
            if (!ReaderGenerator.ImportReferences(moduleDef))
                return false;
            if (!GenericWriterHelper.ImportReferences(moduleDef))
                return false;
            if (!GenericReaderHelper.ImportReferences(moduleDef))
                return false;
            if (!SyncHandlerGenerator.ImportReferences(moduleDef))
                return false;

            return true;
        }


        internal static bool IsFishNetAssembly(ICompiledAssembly assembly) => (assembly.Name == FishNetILPP.RUNTIME_ASSEMBLY_NAME);
        internal static bool IsFishNetAssembly(ModuleDefinition moduleDef) => (moduleDef.Assembly.Name.Name == FishNetILPP.RUNTIME_ASSEMBLY_NAME);

    }
}