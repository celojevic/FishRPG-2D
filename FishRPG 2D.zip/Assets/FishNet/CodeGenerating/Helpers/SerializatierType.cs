﻿namespace FishNet.CodeGenerating.Helping
{

    internal enum SerializerType
    {
        Invalid,
        Enum,
        Array,
        List,
        NetworkBehaviour,
        ClassOrStruct
    }

}