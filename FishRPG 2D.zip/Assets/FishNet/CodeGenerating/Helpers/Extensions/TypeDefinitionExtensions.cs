﻿using Mono.Cecil;
using System;
using System.Linq;


namespace FishNet.CodeGenerating.Helping.Extension
{


    internal static class TypeDefinitionExtensions
    {
        /// <summary>
        /// Returns if the BaseType for TypeDef exist and is not NetworkBehaviour,
        /// </summary>
        /// <param name="typeDef"></param>
        /// <returns></returns>
        internal static bool NonNetworkBehaviourBaseType(this TypeDefinition typeDef)
        {
            return (typeDef.BaseType != null && typeDef.BaseType.FullName != ObjectHelper.NetworkBehaviour_FullName);
        }
        /// <summary>
        /// Returns if typeDef is static (abstract, sealed).
        /// </summary>
        /// <param name="typeDef"></param>
        /// <returns></returns>
        internal static bool IsStatic(this TypeDefinition typeDef)
        {
            //Combing flags in a single check some reason doesn't work right with HasFlag.
            return (typeDef.Attributes.HasFlag(TypeAttributes.Abstract) && typeDef.Attributes.HasFlag(TypeAttributes.Sealed));
        }

        /// <summary>
        /// Gets an enum underlying type for typeDef.
        /// </summary>
        /// <param name="typeDef"></param>
        /// <returns></returns>
        internal static TypeReference GetEnumUnderlyingTypeReference(this TypeDefinition typeDef)
        {
            foreach (FieldDefinition field in typeDef.Fields)
            {
                if (!field.IsStatic)
                    return field.FieldType;
            }
            throw new ArgumentException($"Invalid enum {typeDef.FullName}");
        }

        /// <summary>
        /// Returns if typeDef is derived from type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="typeDef"></param>
        /// <returns></returns>
        internal static bool IsDerivedFrom<T>(this TypeDefinition typeDef)
        {
            return IsDerivedFrom(typeDef, typeof(T));
        }

        /// <summary>
        /// Returns if typeDef is derived from type.
        /// </summary>
        /// <param name="typeDef"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        internal static bool IsDerivedFrom(this TypeDefinition typeDef, Type type)
        {

            if (!typeDef.IsClass)
                return false;

            // are ANY parent classes of baseClass?
            TypeReference parent = typeDef.BaseType;

            if (parent == null)
                return false;

            if (parent.Is(type))
                return true;

            if (parent.CanBeResolved())
                return IsDerivedFrom(parent.Resolve(), type);

            return false;
        }

        /// <summary>
        /// Adds a method to typeDef.
        /// </summary>
        /// <param name="typDef"></param>
        /// <param name="methodName"></param>
        /// <param name="attributes"></param>
        /// <returns></returns>
        internal static MethodDefinition AddMethod(this TypeDefinition typDef, string methodName, MethodAttributes attributes)
        {
            return AddMethod(typDef, methodName, attributes, typDef.Module.ImportReference(typeof(void)));
        }
        /// <summary>
        /// Adds a method to typeDef.
        /// </summary>
        /// <param name="typeDef"></param>
        /// <param name="methodName"></param>
        /// <param name="attributes"></param>
        /// <param name="typeReference"></param>
        /// <returns></returns>
        internal static MethodDefinition AddMethod(this TypeDefinition typeDef, string methodName, MethodAttributes attributes, TypeReference typeReference)
        {
            var method = new MethodDefinition(methodName, attributes, typeReference);
            typeDef.Methods.Add(method);
            return method;
        }


        /// <summary>
        /// Finds the first method by a given name.
        /// </summary>
        /// <param name="typeDef"></param>
        /// <param name="methodName"></param>
        /// <returns></returns>
        internal static MethodDefinition GetMethod(this TypeDefinition typeDef, string methodName)
        {
            return typeDef.Methods.FirstOrDefault(method => method.Name == methodName);
        }

        /// <summary>
        /// Returns if a type is a subclass of another.
        /// </summary>
        /// <param name="typeDef"></param>
        /// <param name="ClassTypeFullName"></param>
        /// <returns></returns>
        internal static bool IsSubclassOf(this TypeDefinition typeDef, string ClassTypeFullName)
        {
            if (!typeDef.IsClass) return false;

            TypeReference baseTypeRef = typeDef.BaseType;
            while (baseTypeRef != null)
            {
                if (baseTypeRef.FullName == ClassTypeFullName)
                {
                    return true;
                }

                try
                {
                    baseTypeRef = baseTypeRef.Resolve().BaseType;
                }
                catch
                {
                    return false;
                }
            }

            return false;
        }

        /// <summary>
        /// Gets a field reference by name.
        /// </summary>
        /// <param name="typeDef"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static FieldReference GetField(this TypeDefinition typeDef, string fieldName)
        {
            if (typeDef.HasFields)
            {
                for (int i = 0; i < typeDef.Fields.Count; i++)
                {
                    if (typeDef.Fields[i].Name == fieldName)
                    {
                        return typeDef.Fields[i];
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Returns if the TypeDefinition implements TInterface.
        /// </summary>
        /// <typeparam name="TInterface"></typeparam>
        /// <param name="typeDef"></param>
        /// <returns></returns>
        public static bool ImplementsInterface<TInterface>(this TypeDefinition typeDef)
        {
            TypeDefinition climbTypeDef = typeDef;

            while (climbTypeDef != null)
            {
                if (climbTypeDef.Interfaces.Any(i => i.InterfaceType.Is<TInterface>()))
                    return true;

                try
                {
                    if (climbTypeDef.BaseType != null)
                        climbTypeDef = climbTypeDef.BaseType.Resolve();
                    else
                        climbTypeDef = null;
                }
                //Could not resolve assembly; can happen for assemblies being checked outside FishNet/csharp.
                catch (AssemblyResolutionException)
                {
                    break;
                }
            }

            return false;
        }
    }


}