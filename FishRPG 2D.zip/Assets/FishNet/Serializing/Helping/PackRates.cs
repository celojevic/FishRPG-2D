﻿namespace FishNet.Serializing.Helping
{
    public enum PackRates : byte
    {
        Positive1 = 1,
        Positive2 = 3,
        Positive4 = 5,
        Positive8 = 7,
    } 

}
