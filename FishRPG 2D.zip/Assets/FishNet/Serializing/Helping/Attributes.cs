﻿using System;

namespace FishNet.Serializing.Helping
{
    public class CodegenExcludeAttribute : Attribute { }
    public class CodegenIncludeInternalAttribute : Attribute { }

}