﻿//using System.Runtime.InteropServices;

//namespace FishNet.Serializing
//{
//    [StructLayout(LayoutKind.Auto, CharSet = CharSet.Auto)]
//    public static class GeneratedReadersAndWriters
//    {

//    }
//}
