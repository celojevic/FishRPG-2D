namespace FishNet.Serializing
{
    public enum AutoPackType
    {
        Unpacked = 0,
        Packed = 1
    }
}
