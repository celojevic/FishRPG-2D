using TMPro;
using UnityEngine;

public class Npc : Interactable
{

    public override void Interact(Player player)
    {
        //Debug.Log("TODO open dialogue with this npc");
    }

}
