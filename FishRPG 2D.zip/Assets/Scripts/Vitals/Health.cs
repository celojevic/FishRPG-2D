using System;
using UnityEngine;

public class Health : VitalBase
{



}
