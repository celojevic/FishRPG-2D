using UnityEngine;

public class Mana : VitalBase
{


}
