
public static class Constants
{

    public class Keys
    {
        public const string INTERACT = "KEY_INTERACT";
    }

}
