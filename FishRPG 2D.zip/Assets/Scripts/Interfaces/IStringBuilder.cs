public interface IStringBuilder
{
    public string BuildString();
}
