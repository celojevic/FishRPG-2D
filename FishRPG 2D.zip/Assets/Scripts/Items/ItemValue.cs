
[System.Serializable]
public class ItemValue
{

    public ItemBase Item;

    public int Quantity;

}