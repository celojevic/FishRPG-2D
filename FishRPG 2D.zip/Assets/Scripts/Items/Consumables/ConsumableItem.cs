using UnityEngine;

public abstract class ConsumableItem : ItemBase
{

    public abstract void Use(Player user);

}
