Original sprites by:
https://0x72.itch.io/dungeontileset-ii

Packed by:
https://revenger-wizard.itch.io/dungeon-tileset-assets