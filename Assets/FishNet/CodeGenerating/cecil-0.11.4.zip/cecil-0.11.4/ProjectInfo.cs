//
// Author:
//   Jb Evain (jbevain@gmail.com)
//
// Copyright (c) 2008 - 2015 Jb Evain
//
// Licensed under the MIT/X11 license.
//

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct (Consts.AssemblyName)]
[assembly: AssemblyCopyright ("Copyright © 2008 - 2018 Jb Evain")]

[assembly: ComVisible (false)]

[assembly: AssemblyVersion ("0.11.4.0")]
[assembly: AssemblyFileVersion ("0.11.4.0")]
[assembly: AssemblyInformationalVersion ("0.11.4.0")]
